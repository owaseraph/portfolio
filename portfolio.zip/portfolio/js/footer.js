// footer.js — simple staggered fade-in for the contact footer.

export function initFooter() {
  gsap.fromTo('footer > *', { opacity: 0, y: 16 }, {
    opacity: 1, y: 0, duration: 0.8, stagger: 0.1,
    scrollTrigger: { trigger: 'footer', start: 'top 85%' },
  });
}
