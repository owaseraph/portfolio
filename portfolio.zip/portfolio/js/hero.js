// hero.js — split-character title reveal, scramble-text effect for the
// eyebrow label, and a mouse-reactive grid background in the hero.

const SCRAMBLE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ·/\\_';

export function scrambleIn(el, final, duration = 1.1) {
  let frame = 0;
  const totalFrames = Math.round(duration * 60);
  el.style.opacity = 1;
  const iv = setInterval(() => {
    frame++;
    const progress = frame / totalFrames;
    el.textContent = final.split('').map((ch, i) => {
      if (ch === ' ' || ch === '·') return ch;
      if (i / final.length < progress) return ch;
      return SCRAMBLE_CHARS[Math.floor(Math.random() * SCRAMBLE_CHARS.length)];
    }).join('');
    if (frame >= totalFrames) { clearInterval(iv); el.textContent = final; }
  }, 1000 / 60);
}

export function initHero() {
  // Split-char title reveal
  const heroTitle = document.getElementById('heroTitle');
  if (heroTitle) {
    const text = heroTitle.textContent;
    heroTitle.innerHTML = text.split('').map(c =>
      `<span class="char" style="display:inline-block;transform:translateY(115%)">${c === ' ' ? '&nbsp;' : c}</span>`
    ).join('');
    gsap.to('#heroTitle .char', { y: '0%', duration: 0.9, ease: 'power4.out', stagger: 0.018, delay: 0.3 });
  }

  const heroSub = document.getElementById('heroSub');
  if (heroSub) gsap.to(heroSub, { opacity: 0.85, duration: 0.8, delay: 1.0 });

  // Scramble eyebrow
  const scrambleEl = document.getElementById('scrambleText');
  if (scrambleEl) {
    const finalText = scrambleEl.textContent;
    scrambleEl.style.opacity = 0;
    setTimeout(() => scrambleIn(scrambleEl, finalText), 150);
  }

  // Mouse-reactive grid background
  const gridBg = document.getElementById('gridBg');
  const heroEl = document.querySelector('.hero');
  if (gridBg && heroEl) {
    const gridLines = 14;
    for (let i = 0; i < gridLines; i++) {
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', (i / (gridLines - 1)) * 100 + '%');
      line.setAttribute('y1', '0');
      line.setAttribute('x2', (i / (gridLines - 1)) * 100 + '%');
      line.setAttribute('y2', '100%');
      line.setAttribute('stroke', 'var(--ink)');
      line.setAttribute('stroke-opacity', '0.06');
      gridBg.appendChild(line);
    }
    heroEl.addEventListener('mousemove', e => {
      const r = heroEl.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      gsap.to(gridBg, { x: px * -20, duration: 0.6, ease: 'power2.out' });
    });
  }
}
