// main.js — entry point. Registers GSAP plugins, checks for
// prefers-reduced-motion, and wires up every module.
//
// This file is loaded as <script type="module" src="js/main.js">,
// so every file it imports must use export/import (already set up).

import { initTheme } from './theme.js';
import { initCursor, initMagnetic, disableCursor } from './cursor.js';
import { initHero } from './hero.js';
import { initMarquee, initRevealText, initPinnedGallery } from './gallery.js';
import { initStats } from './stats.js';
import { initTimeline } from './timeline.js';
import { initFooter } from './footer.js';

gsap.registerPlugin(ScrollTrigger);

// Dark mode toggle works regardless of motion preference.
initTheme();

const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (reduced) {
  // Show everything in its resting state, skip all motion/cursor tricks.
  document.querySelectorAll('.hero-sub, .reveal-inner, [data-beat] h2, [data-beat] p, footer > *')
    .forEach(el => { el.style.opacity = 1; el.style.transform = 'none'; });
  disableCursor();
} else {
  initCursor();
  initMagnetic();
  initHero();
  initMarquee();
  initRevealText();
  initPinnedGallery();
  initStats();
  initTimeline();
  initFooter();
}
