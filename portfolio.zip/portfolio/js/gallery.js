// gallery.js — the infinite marquee ticker, the masked h2 line reveals,
// and the pinned horizontal-scroll project gallery.

export function initMarquee() {
  const marqueeTrack = document.getElementById('marqueeTrack');
  if (marqueeTrack) gsap.to(marqueeTrack, { xPercent: -50, duration: 14, ease: 'none', repeat: -1 });
}

export function initRevealText() {
  gsap.utils.toArray('.reveal-inner').forEach(el => {
    gsap.to(el, { y: '0%', duration: 0.9, ease: 'power4.out', scrollTrigger: { trigger: el, start: 'top 88%' } });
  });
  gsap.utils.toArray('#work p.lead').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 14 }, {
      opacity: 1, y: 0, duration: 0.8, scrollTrigger: { trigger: el, start: 'top 88%' },
    });
  });
}

export function initPinnedGallery() {
  const track = document.getElementById('track');
  const pinSection = document.getElementById('pinSection');
  const pinFill = document.getElementById('pinProgressFill');
  if (!track || !pinSection || !pinFill) return;

  function build() {
    const distance = Math.max(track.scrollWidth - window.innerWidth + 64, 100);
    ScrollTrigger.getById('pinScroll')?.kill();
    gsap.to(track, {
      x: -distance,
      ease: 'none',
      scrollTrigger: {
        id: 'pinScroll',
        trigger: pinSection,
        start: 'top top',
        end: () => '+=' + distance,
        scrub: 0.6,
        pin: true,
        onUpdate: self => { pinFill.style.width = (self.progress * 100) + '%'; },
      },
    });
  }

  build();
  window.addEventListener('resize', () => ScrollTrigger.refresh());
}
